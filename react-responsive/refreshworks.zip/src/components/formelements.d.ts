export interface FormValues {
  [key: string]: string;
}

type IFieldTypes =
  | "text"
  | "textArea"
  | "email"
  | "password"
  | "confirmPassword"
  | "boolean"
  | "checkbox"
  | "date"
  | "tel"
  | "radio"
  | "select";

export interface FormField {
  name: string;
  label: string;
  type: IFieldTypes;
  placeholder?: string;
  required?: boolean;
  minDate?: string;
  maxDate?: string;
  maxlen?: number;
  minlen?: number;
  options?: { label: string; value: string }[];
  initialValue?: string | boolean | number;
  value?: string;
  dependsOn?: string;
}

export interface FormSection {
  name: string;
  label: string;
  formFields: FormField[];
}

export interface FormSchema {
  sections: FormSection[];
}
