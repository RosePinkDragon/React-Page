import FormGenerator from "./components/FormGenerator";
import testData from "./testData";

const App = () => {
  return <FormGenerator formData={testData} />;
};

export default App;
