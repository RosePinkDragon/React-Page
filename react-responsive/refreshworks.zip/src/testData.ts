import type { FormSchema } from "./components/formelements";

export default {
  sections: [
    {
      name: "questionnaire",
      label: "Questionnaire",
      formFields: [
        {
          name: "question1",
          label: "Question 1",
          type: "boolean",
          required: true,
        },
        {
          dependsOn: "question1",
          name: "firstName",
          label: "First Name",
          type: "text",
          placeholder: "Enter your first name",
          required: true,
        },
      ],
    },
  ],
} as FormSchema;
